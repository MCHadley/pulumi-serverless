const { S3 } = require("@aws-sdk/client-s3");
const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand } = require('@aws-sdk/lib-dynamodb');

const s3 = new S3();
const client = new DynamoDBClient({ region: 'us-east-1' })
const ddbDocClient = DynamoDBDocumentClient.from(client)

const putItem = async (input) => {
    const putCommand = new PutCommand(input);
    let response;
    try {
        response = await ddbDocClient.send(putCommand);
        return response;
    } catch (error) {
        console.error(`Error putting item ${error}`);
        throw error;
    }
};

export const handler = async (event) => {
    const bucket = event.Records[0].s3.bucket.name;
    const key = decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, ' '))
    const params = {
        Bucket: bucket,
        Key: key,
    };
    try {
        const { Key, LastModified } = await s3.getObject(params)
        let input = {
            TableName: "file-index",
            Item: {
                fileId: Key,
                timestamp: LastModified
            }
        }
        const result = await putItem(input);
        return result
    } catch (error) {
        console.error(`There was an error ${error}`)
        throw error;
    }
}